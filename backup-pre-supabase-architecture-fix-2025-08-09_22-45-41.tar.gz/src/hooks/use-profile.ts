
// Re-export from the profile directory
export { useProfile, type UserProfileData } from './profile';
