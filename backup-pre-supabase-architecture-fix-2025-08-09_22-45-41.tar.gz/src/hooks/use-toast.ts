
// Re-export from the toast directory to maintain backward compatibility
import { useToast } from "./toast/use-toast";
import { toast } from "./toast/toast";

export { useToast, toast };
