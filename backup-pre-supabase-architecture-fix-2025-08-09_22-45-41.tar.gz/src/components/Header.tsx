
// Re-export the Header component from the new location
import Header from './header/Header';
export default Header;
